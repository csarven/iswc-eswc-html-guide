## Introduction
{:#introduction}

This is a great article on the [Semantic Web](cite:cites semanticweb), written in Markdown.

Make sure to [write your document effectively](http://www.treesmapsandtheorems.com/pdfs/TM&Th-2.0-summary.pdf)!

Write proper introduction.
More information on snippets like this can be found on the [ScholarMarkdown wiki](https://github.com/rubensworks/ScholarMarkdown/wiki/Snippets).
{:.todo}
