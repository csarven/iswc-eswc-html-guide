# My Scholarly Article

## Build
```
bundle install
bundle exec nanoc compile
```

## Development mode
```
bundle install
bundle exec guard
```

View on http://localhost:3000/
