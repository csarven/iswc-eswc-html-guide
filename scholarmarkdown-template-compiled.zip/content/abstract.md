## Abstract
<!-- Context      -->
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
<!-- Need         -->
Vestibulum finibus dignissim augue, id pellentesque est facilisis non.
<!-- Task         -->
Donec fringilla dolor non neque iaculis blandit.
<!-- Object       -->
Praesent aliquet eleifend iaculis.
<!-- Findings     -->
Quisque pellentesque at odio ac bibendum.
<!-- Conclusion   -->
Pellentesque imperdiet felis urna, quis facilisis lacus gravida non.
<!-- Perspectives -->
Donec quis lectus eget sem tempor tristique pellentesque in dolor.
