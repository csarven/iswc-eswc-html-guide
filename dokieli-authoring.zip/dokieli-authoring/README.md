# Authoring Guide

Thanks for joining this initiative!

If you need help, just ask at https://gitter.im/linkeddata/dokieli or https://gitter.im/linkedresearch/chat . The dokieli source is available at https://github.com/linkeddata/dokieli and so you should refer to that if you want most up to date releases. If you want to get a feel of what's out there, see some of the articles self-published by other authors: https://github.com/linkeddata/dokieli/wiki#examples-in-the-wild and the kind of information they include in their articles beyond the core content.

## Before you start

This package includes the authoring guidelines for ACM and LNCS. The HTML templates (acm-sigproc-sp, lncs-splnproc) and corresponding CSS are only intended to mimic the original guidelines in PDF that the publishers make available. They demonstrate the kind of things that normally go into scholarly articles.

There is nothing particularly different between the HTML templates included in this package - they are interchangeable, however, the primary CSS they use have their own look and feel. For example, lncs-splnproc uses media/css/lncs.css as primary, and media/css/acm.css as secondary. For most cases, you can use the same HTML with either ACM, LNCS, IOS Press', Basic CSS etc. See the media/css/ directory. LNCS uses the Computer Modern fonts (see media/fonts/) to match the authoring guidelines, but if you don't want them, either remove the links from the CSS or use your own fonts.


## How to prepare your article

Depending on the template you want to reuse, consider making a copy of it to index.html eg:

* `cp lncs-splnproc index.html` or
* `cp acm-sigproc-sp index.html`

Two general approaches:

1. If you feel comfortable with HTML or LaTeX writing, start with one of the HTML templates and update with your own content. This should be fairly straight-forward - just stick to common HTML patterns. Bonus points for RDFa! :)

2. If you prefer to work with a GUI, load up your HTML in your Web browser and use dokieli's interface. Trigger the authoring mode by clicking 'Edit' from the dokieli menu (top right), or use 'Source' from the menu.

For most cases, you don't need to make changes to the CSS, but of course there may be bugs or cases that doesn't quite handle what you are trying to do. In that case, go ahead and edit, and if you think it should become part of the package, please make a pull request at dokieli's repository or mention in chat.

All of the content in HTML should be human-visible and should not require CSS or JavaScript. So, treat the CSS and JavaScript that's included in this package as things that progressively enhance your document. dokieli and the *Linked Research* initiative encourages this approach, so your final article does not at all require the dokieli.css and dokieli.js for everything to function. Feel free to include or exclude them (inside the `<head>` block in HTML) to fit your own needs.

### Final checks

You might want to double-check your work by running the HTML through a validator (eg https://validator.w3.org/ ), or with something like `xmllint` from command-line. See also http://rdf.greggkellogg.net/distiller for RDF. Such tools are very useful to assist in making sure the documents are human and machine-readable. However, they may sometimes show incorrect errors or warnings. So, use them to assist your work but remain skeptical.


## How to share and publish

### Offline sharing

Simply create a ZIP archive of all the required files, starting with HTML and the CSS that's applied, as well as the images, and any scripts.

### Online publishing

You are now free to publish your article virtually from any HTTP server. That can be at your personal or institution's website, GitHub pages, a gist or pastebin of sorts.

If you want to completely "control" your own publishing, do it from your personal website! Consider setting up a Solid server (eg https://github.com/solid/node-solid-server/ ) and server your article from there. A Solid server and dokieli together opens up many possibilities eg. collaborative annotations, notifications,.. available as Linked Data.

If you've gone this far, announce your work to the Linked Open Research Cloud: https://linkedresearch.org/cloud :) It is just a matter of sending a notification referencing your article's URI.

Share your URI everywhere else and make sure to add it to https://github.com/linkeddata/dokieli/wiki#examples-in-the-wild

Have fun!
